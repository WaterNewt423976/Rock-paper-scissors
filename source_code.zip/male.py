from random import randint
from time import sleep
from pickle import *
def loose():
    print("YOU LOST!!!")

def win():
    print("YOU WON!!!")
print("HINT: You're playing against a male.")
print("Type 'START' to start the game")
startgame = input(": ")

if startgame=="START":
    print("ROCK")
    sleep(0.5)
    print("PAPER")
    sleep(0.5)
    print("SCISSORS")
    sleep(0.5)
    print("SHOOT")
    sleep(0.1)
    print("")
    n = randint(0,4)
    if n==0:
        n = "ROCK"
    elif n==1:
        n = "ROCK"
    elif n==2:
        n = "PAPER"
    elif n==3:
        n = "SCISSORS"
    elif n==4:
        n = "ROCK"
    print("ROCK PAPER or SCISSORS: ")
    youranswer = input("[R/P/S]")
    if youranswer=="R" and n=="SCISSORS":
        finalanswer = "ROCK"
        win()
    elif youranswer=="P" and n=="ROCK":
        finalanswer = "PAPER"
        win()
    elif youranswer=="S" and n=="PAPER":
        finalanswer = "SCISSORS"
        win()
    else:
        loose()
    print(n)
input("Press any key to exit... ")
