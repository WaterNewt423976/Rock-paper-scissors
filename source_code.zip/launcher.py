from os import system
print("Who do you want to play with? FEMALE OR MALE")
who = input("[F/M]")
if who=="F":
    system("python female.py")
elif who=="M":
    system("python male.py")
else:
    print("Please try again.")